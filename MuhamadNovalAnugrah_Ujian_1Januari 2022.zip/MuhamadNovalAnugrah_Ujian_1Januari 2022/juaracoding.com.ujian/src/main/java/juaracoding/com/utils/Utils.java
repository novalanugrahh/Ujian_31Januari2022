package juaracoding.com.utils;

public class Utils {
	
	public static int testCount = 0;

}
